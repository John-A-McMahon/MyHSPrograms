/* Write the class Radio
 * 
 * Instance variable for frequency (double freq)
 * 
 * void setStation(double station)
 * double getStation()
 * void changeStation(double amnt)
 * void nextStation() +0.2
 * void prevStation() -0.2
 */